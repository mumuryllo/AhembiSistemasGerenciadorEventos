import exceptions.EnderecoException;
import exceptions.EventosException;
import exceptions.UsuarioException;
import servicos.MenuService;

public class Main {
    public static void main(String[] args) throws EnderecoException, UsuarioException, EventosException {
        MenuService service = new MenuService();
        service.exibirMenu();
    }
}