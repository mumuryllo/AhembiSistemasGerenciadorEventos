package servicos;
import entidades.Endereco;
import entidades.Usuario;
import enums.TipoUsuario;
import exceptions.EnderecoException;
import exceptions.UsuarioException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class UsuarioService {

    private List<Usuario> listaUsuarios;
    private Scanner scanner;
    private EnderecoService enderecoService;

    public UsuarioService() {
        this.listaUsuarios = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        this.enderecoService = new EnderecoService();
    }


    public Usuario cadastrarUsuario() throws EnderecoException, UsuarioException {
        System.out.println("Cadastro de novo usuário:");

        String nome = lerNome();
        String email = lerEmail();
        int idade = lerIdade();
        Endereco endereco = enderecoService.cadastrarEndereco();
        TipoUsuario tipoUsuario = selecionarTipoUsuario();

        Usuario novoUsuario = new Usuario(nome, email, idade, endereco, tipoUsuario);

        if (listaUsuarios.add(novoUsuario)) {
            System.out.println("Usuário cadastrado com sucesso!");
            mostrarDadosUsuario(novoUsuario);
        } else {
            throw new UsuarioException("Erro ao cadastrar usuário. Por favor, tente novamente.");
        }

        System.out.println(listaUsuarios.size());
        return novoUsuario;
    }


    public Usuario buscarUsuarioPorNome(String nome) {
        if (nome == null || nome.isEmpty()) {
            return null;
        }

        for (Usuario usuario : listaUsuarios) {
            String nomeUsuario= usuario.getNome();
            System.out.println("Comparando: " + nomeUsuario + " com " + nome);
            if (nomeUsuario.equalsIgnoreCase(nome)) {
                return usuario;
            }
        }
        return null;
    }
        private String lerNome() throws UsuarioException {
            return lerEntrada("Nome: ", "Nome inválido. Por favor, insira um nome válido.");
        }

    private String lerEmail(){
        String email = null;
        boolean emailValido = false;

        do {
            System.out.print("Email: ");
            email = scanner.nextLine().trim();

            if (email.contains("@") && email.contains(".") && email.length() >= 5) {
                emailValido = true;
            } else {
                System.out.println("Email inválido. Por favor, insira um email válido.");
            }
        } while (!emailValido);

        return email;
    }

    private int lerIdade() {
        int idade = 0;

        do {
            try {
                System.out.print("Idade: ");
                idade = Integer.parseInt(scanner.nextLine());

                if (idade < 18) {
                    System.out.println("Idade inválida. A idade deve ser maior que zero e pelo menos 18 anos.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Idade inválida. Por favor, insira um número válido.");
            }catch (InputMismatchException e) {
                System.out.println("Idade inválida. Voce inseriu letra.");
            }
        } while (idade < 18);

        return idade;
    }
        private TipoUsuario selecionarTipoUsuario() {
            System.out.println("Selecione o tipo de usuário:");
            System.out.println("1. Estudante");
            System.out.println("2. Organizador");

            int opcao = 0;
            do {
                try {
                    opcao = scanner.nextInt();
                    scanner.nextLine();

                    switch (opcao) {
                        case 1:
                            return TipoUsuario.ESTUDANTE;
                        case 2:
                            return TipoUsuario.ORGANIZADOR;
                        default:
                            System.out.println("Opção inválida. Tente novamente.");
                            break;
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Você digitou letra em vez de número. Digite novamente.");
                    scanner.nextLine();
                }

            } while (true);
        }

        private String lerEntrada(String mensagem, String erro) throws UsuarioException {
            System.out.print(mensagem);
            String entrada = scanner.nextLine();
            if (entrada.isEmpty()) {
                System.out.println(erro);
                throw new UsuarioException(erro);
            }
            return entrada;
        }

        private void mostrarDadosUsuario(Usuario usuario) {
            System.out.println("Dados do usuário cadastrado:");
            System.out.println("Nome: " + usuario.getNome());
            System.out.println("Email: " + usuario.getEmail());
            System.out.println("Idade: " + usuario.getIdade());
            System.out.println("Endereço:");
            enderecoService.mostrarEndereco(usuario.getEndereco());
            System.out.println("Tipo de usuário: " + usuario.getTipoUsuario());
        }
    }

