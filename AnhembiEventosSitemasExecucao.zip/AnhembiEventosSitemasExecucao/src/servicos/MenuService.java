package servicos;

import entidades.Evento;
import entidades.Usuario;
import enums.TipoUsuario;
import exceptions.EnderecoException;
import exceptions.EventosException;
import exceptions.UsuarioException;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MenuService {
    private UsuarioService usuarioService;
    private EventosService eventosService;
    private Scanner scanner;

    public MenuService() {
        this.usuarioService = new UsuarioService();
        this.eventosService = new EventosService();
        this.scanner = new Scanner(System.in);
    }


    public void exibirMenu() throws EnderecoException, UsuarioException, EventosException {
        int opcao = 0;
        do {
            try {
                mostrarOpcoes();
                opcao = scanner.nextInt();
                scanner.nextLine();

                switch (opcao) {
                    case 1:
                        usuarioService.cadastrarUsuario();
                        break;
                    case 2:
                        cadastrarNovoEvento();
                        break;
                    case 3:
                        eventosService.listarEventos();
                        break;
                    case 4:
                        participarDeEvento();
                        break;
                    case 5:
                        visualizarEventosInscritos();
                        break;
                    case 6:
                        cancelarParticipacaoEvento();
                        break;
                    case 7:
                        eventosService.ordenarEventosPorHorario();
                        break;
                    case 8:
                        eventosService.verificarEventosOcorrendo();
                        break;
                    case 9:
                        eventosService.informarEventosPassados();
                        break;
                    case 0:
                        System.out.println("Saindo do sistema...");
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Você digitou letra em vez de número.");
                scanner.nextLine();
            }

        } while (opcao != 0);
    }


    private void mostrarOpcoes() {
        System.out.println("\n----- Menu -----");
        System.out.println("1. Cadastrar novo usuário");
        System.out.println("2. Cadastrar novo evento");
        System.out.println("3. Listar eventos cadastrados");
        System.out.println("4. Participar de evento");
        System.out.println("5. Visualizar eventos inscritos");
        System.out.println("6. Cancelar participação em evento");
        System.out.println("7. Ordenar eventos por horário");
        System.out.println("8. Verificar eventos ocorrendo agora");
        System.out.println("9. Informar eventos passados");
        System.out.println("0. Sair");
        System.out.print("Escolha uma opção: ");
    }

    private void cadastrarNovoEvento() throws EventosException {
        System.out.print("Informe o nome do usuário: ");
        String nomeUsuario = scanner.next();
        Usuario usuario = usuarioService.buscarUsuarioPorNome(nomeUsuario);
        if (usuario != null && usuario.getTipoUsuario() == TipoUsuario.ORGANIZADOR) {
            eventosService.cadastrarEvento();
        } else {
            System.out.println("Apenas usuários do tipo ORGANIZADOR podem cadastrar eventos.");
        }
    }

    private void participarEvento(Usuario usuario, Evento evento) {
        if (usuario != null && evento != null) {
            usuario.adicionarEvento(evento);
            System.out.println("Você se inscreveu no evento: " + evento.getNome());
        } else {
            System.out.println("Usuário ou evento não encontrado.");
        }
    }
    private void cancelarParticipacaoEvento(Usuario usuario, Evento evento) {
        usuario.removerEvento(evento);
        System.out.println("Você cancelou sua participação no evento: " + evento.getNome());
    }

    private void participarDeEvento() {
        System.out.println("Participação em evento:");
        System.out.print("Informe seu nome de usuário: ");
        String nomeUsuario = scanner.nextLine();

        Usuario usuario = usuarioService.buscarUsuarioPorNome(nomeUsuario);

        if (usuario != null) {
            eventosService.listarEventos();
            System.out.print("Informe o nome do evento que deseja participar: ");
            String nomeEvento = scanner.nextLine();

            Evento evento = eventosService.buscarEventoPorNome(nomeEvento);

            if (evento != null) {
                participarEvento(usuario, evento);
            } else {
                System.out.println("Evento não encontrado.");
            }
        } else {
            System.out.println("Usuário não encontrado.");
        }
    }

    private void visualizarEventosInscritos() {
        System.out.println("Visualizar eventos inscritos:");
        System.out.print("Informe seu nome de usuário: ");
        String nomeUsuario = scanner.nextLine();

        Usuario usuario = usuarioService.buscarUsuarioPorNome(nomeUsuario);

        if (usuario != null) {
            eventosService.visualizarEventosConfirmados(usuario);
        } else {
            System.out.println("Usuário não encontrado.");
        }
    }

    private void cancelarParticipacaoEvento() {
        System.out.println("Cancelar participação em evento:");
        System.out.print("Informe seu nome de usuário: ");
        String nomeUsuario = scanner.nextLine();
        System.out.print("Informe o nome do evento que deseja cancelar: ");
        String nomeEvento = scanner.nextLine();

        Usuario usuario = usuarioService.buscarUsuarioPorNome(nomeUsuario);
        Evento evento = eventosService.buscarEventoPorNome(nomeEvento);

        if (usuario != null && evento != null) {
            cancelarParticipacaoEvento(usuario, evento);
        } else {
            System.out.println("Usuário ou evento não encontrado.");
        }
    }
}