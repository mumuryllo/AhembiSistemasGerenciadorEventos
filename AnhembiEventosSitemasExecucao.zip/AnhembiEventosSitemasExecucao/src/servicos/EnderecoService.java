package servicos;
import entidades.Endereco;
import exceptions.EnderecoException;
import java.util.Scanner;

public class EnderecoService {
    private Scanner scanner;

    public EnderecoService() {
        this.scanner = new Scanner(System.in);
    }

    public Endereco cadastrarEndereco() throws EnderecoException {
        System.out.println("Cadastro de endereço:");
        String cidade = lerEntrada("Cidade: ", "Cidade não pode estar vazia.");
        String bairro = lerEntrada("Bairro: ", "Bairro não pode estar vazio.");
        String rua = lerEntrada("Rua: ", "Rua não pode estar vazia.");
        return new Endereco(cidade, bairro, rua);
    }

    private String lerEntrada(String mensagem, String erro) throws EnderecoException {
        System.out.print(mensagem);
        String entrada = scanner.nextLine();
        if (entrada.isEmpty()) {
            System.out.println(erro);
            throw new EnderecoException(erro);
        }
        return entrada;
    }

    public void mostrarEndereco(Endereco endereco) {
        System.out.println("Endereço:");
        System.out.println("Cidade: " + endereco.getCidade());
        System.out.println("Bairro: " + endereco.getBairro());
        System.out.println("Rua: " + endereco.getRua());
    }
}