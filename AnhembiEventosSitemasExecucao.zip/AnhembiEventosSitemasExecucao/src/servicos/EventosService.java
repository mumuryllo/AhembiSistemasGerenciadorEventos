package servicos;
import entidades.Endereco;
import entidades.Evento;
import entidades.Usuario;
import enums.Categoria;
import exceptions.EnderecoException;
import exceptions.EventosException;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class EventosService {

    private List<Evento> eventos;
    private List<Usuario> usuarios;
    private Scanner scanner;
    private EnderecoService enderecoService;
    private UsuarioService usuarioService;

    private static final String FILENAME = "C:\\Users\\muryllo.severino\\Desktop\\AnhembiEventosSistema\\Data\\events.txt";

    public EventosService() {
        this.eventos = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        this.enderecoService = new EnderecoService();
        this.usuarioService = new UsuarioService();
        this.usuarios = new ArrayList<>();
        carregarEventos();
    }

    public Evento cadastrarEvento() throws EventosException {
        System.out.println("Cadastro de novo evento:");
        String nome = lerNome();
        String descricao = lerDescricao();
        Categoria categoria = selecionarCategoria();
        Endereco endereco;
        try {
            endereco = enderecoService.cadastrarEndereco();
        } catch (EnderecoException e) {
            throw new EventosException("Erro ao cadastrar evento: " + e.getMessage());
        }
        LocalDateTime horarioEvento = lerHorarioEvento();
        Evento novoEvento = new Evento(nome, descricao, categoria, endereco, horarioEvento);
        eventos.add(novoEvento);
        salvarEventos();
        return novoEvento;
    }
    public void listarEventos() {
        System.out.println("Lista de eventos cadastrados:");
        eventos.forEach(this::mostrarInformacoesEvento);
        System.out.println(eventos.size());

    }

    public void ordenarEventosPorHorario() {
        List<Evento> eventosOrdenados = eventos.stream()
                .sorted(Comparator.comparing(Evento::getHorarioEvento))
                .collect(Collectors.toList());

        System.out.println("Eventos ordenados por horário:");
        eventosOrdenados.forEach(this::mostrarInformacoesEvento);
    }

    public void verificarEventosOcorrendo() {
        LocalDateTime agora = LocalDateTime.now();

        List<Evento> eventosOcorrendo = eventos.stream()
                .filter(evento -> evento.getHorarioEvento().isBefore(agora))
                .collect(Collectors.toList());

        if (eventosOcorrendo.isEmpty()) {
            System.out.println("Não há eventos ocorrendo no momento.");
        } else {
            System.out.println("Eventos ocorrendo neste momento:");
            eventosOcorrendo.forEach(this::mostrarInformacoesEvento);
        }
    }

    public void informarEventosPassados() {
        LocalDateTime agora = LocalDateTime.now();

        List<Evento> eventosPassados = eventos.stream()
                .filter(evento -> evento.getHorarioEvento().isBefore(agora))
                .collect(Collectors.toList());

        if (eventosPassados.isEmpty()) {
            System.out.println("Não há eventos passados.");
        } else {
            System.out.println("Eventos que já ocorreram:");
            eventosPassados.forEach(this::mostrarInformacoesEvento);
        }
    }


    private String lerNome() throws EventosException {
        System.out.print("Nome: ");
        String nome = scanner.nextLine().trim();
        if (nome.isEmpty()) {
            throw new EventosException("Nome inválido. Por favor, insira um nome válido.");
        }
        return nome;
    }

    private String lerDescricao() {
        System.out.print("Descrição: ");
        return scanner.nextLine();
    }

    public Evento buscarEventoPorNome(String nome) {
        for (Evento evento : eventos) {
            if (evento.getNome().trim().equalsIgnoreCase(nome.trim())) {
                return evento;
            }
        }
        return null;
    }
    public void visualizarEventosConfirmados(Usuario usuario) {
        List<Evento> eventosConfirmados = usuario.getEventos();
        if (eventosConfirmados.isEmpty()) {
            System.out.println("Você não se inscreveu em nenhum evento.");
        } else {
            System.out.println("Eventos em que você está inscrito:");
            eventosConfirmados.forEach(this::mostrarInformacoesEvento);
        }
    }

    private Categoria selecionarCategoria() {
        System.out.println("Selecione a categoria do evento:");
        for (Categoria categoria : Categoria.values()) {
            System.out.println((categoria.ordinal() + 1) + ". " + categoria.name());
        }
        int opcao = 0;
        try {
            opcao = scanner.nextInt();
            scanner.nextLine();
            if (opcao < 1 || opcao > Categoria.values().length) {
                System.out.println("Opção inválida. Será cadastrado como 'Outro'.");
            }
            return Categoria.values()[opcao - 1];
        } catch (InputMismatchException e) {
            System.out.println("Você digitou uma letra em vez de um número digite de novo.");
            scanner.nextLine();
        }
        return Categoria.values()[opcao - 1];
    }

    private LocalDateTime lerHorarioEvento() {
        System.out.print("Horário do evento (dd/MM/yyyy HH:mm): ");
        String horarioStr = scanner.nextLine();

        try {
            return LocalDateTime.parse(horarioStr, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        } catch (Exception e) {
            System.out.println("Formato de data inválido. Será usado o horário atual.");
            return LocalDateTime.now();
        }
    }

    private void mostrarInformacoesEvento(Evento evento) {
        System.out.println("\nNome: " + evento.getNome());
        System.out.println("Descrição: " + evento.getDescricao());
        System.out.println("Categoria: " + evento.getCategoria());
        enderecoService.mostrarEndereco(evento.getEndereco());
        System.out.println("Horário do Evento: " + evento.getHorarioEvento());
    }


    private void salvarEventos() {
        try (PrintWriter writer = new PrintWriter(FILENAME)) {
            for (Evento evento : eventos) {
                writer.println(evento.getNome());
                writer.println(evento.getDescricao());
                writer.println(evento.getCategoria());
                writer.println(evento.getHorarioEvento());
                writer.println(evento.getEndereco().getCidade());
                writer.println(evento.getEndereco().getBairro());
                writer.println(evento.getEndereco().getRua());
                writer.println();
            }
            System.out.println("Evento salvo com sucesso.");
        } catch (IOException e) {
            System.out.println("Erro ao salvar evento: " + e.getMessage());
        }
    }

    private void carregarEventos() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILENAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String nome = line;
                String descricao = reader.readLine();
                String categoriaStr = reader.readLine();
                Categoria categoria = null;
                try {
                    categoria = Categoria.valueOf(categoriaStr);
                } catch (IllegalArgumentException e) {
                    System.out.println("Categoria inválida: " + categoriaStr);
                }
                LocalDateTime horarioEvento = LocalDateTime.parse(reader.readLine());
                String cidade = reader.readLine();
                String bairro = reader.readLine();
                String rua = reader.readLine();

                Endereco endereco = new Endereco(cidade, bairro, rua);
                reader.readLine();

                Evento evento = new Evento(nome, descricao, categoria, endereco, horarioEvento);
                eventos.add(evento);
            }
            System.out.println("Eventos carregados com sucesso.");
        } catch (IOException e) {
            System.out.println("Erro ao carregar eventos: " + e.getMessage());
        }
    }


}