package entidades;
import enums.TipoUsuario;
import java.util.ArrayList;
import java.util.List;


public class Usuario {

    private String nome;
    private String email;
    private int idade;
    private Endereco endereco;
    private TipoUsuario tipoUsuario;
    private List<Evento> eventos;
    public Usuario(String nome, String email, int idade, Endereco endereco, TipoUsuario tipoUsuario) {
        this.nome = nome;
        this.email = email;
        this.idade = idade;
        this.endereco = endereco;
        this.tipoUsuario = tipoUsuario;
        this.eventos = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public int getIdade() {
        return idade;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public TipoUsuario getTipoUsuario() {
        return tipoUsuario;
    }

    public List<Evento> getEventos() {
        return eventos;
    }

    public void adicionarEvento(Evento evento) {
        eventos.add(evento);
    }

    public void removerEvento(Evento evento) {
        eventos.remove(evento);
    }

}