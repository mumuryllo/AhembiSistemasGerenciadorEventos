package entidades;
import enums.Categoria;
import java.time.LocalDateTime;
public class Evento {

    private String nome;
    private String descricao;
    private Categoria categoria;
    private Endereco endereco;
    private LocalDateTime horarioEvento;

    public Evento(String nome, String descricao, Categoria categoria, Endereco endereco, LocalDateTime horarioEvento) {
        this.nome = nome;
        this.descricao = descricao;
        this.categoria = categoria;
        this.endereco = endereco;
        this.horarioEvento = horarioEvento;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public LocalDateTime getHorarioEvento() {
        return horarioEvento;
    }

}