package enums;

public enum TipoUsuario {
    ESTUDANTE,ORGANIZADOR
}
