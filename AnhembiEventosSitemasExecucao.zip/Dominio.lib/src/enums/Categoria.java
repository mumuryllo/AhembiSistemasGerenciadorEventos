package enums;

public enum Categoria {
    SHOW,EVENTO,ESPORTIVO,FESTA,FESTIVAL
}
