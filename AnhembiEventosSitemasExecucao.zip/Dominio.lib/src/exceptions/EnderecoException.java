package exceptions;

public class EnderecoException extends  Exception{

    public EnderecoException(String mensagem){}

}
