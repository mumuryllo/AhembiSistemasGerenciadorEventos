package exceptions;

public class EventosException extends  Exception{

    public EventosException(String mensagem){}

}
