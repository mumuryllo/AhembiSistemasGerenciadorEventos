package exceptions;

public class UsuarioException extends  Exception{

    public UsuarioException(String mensagem){}

}
